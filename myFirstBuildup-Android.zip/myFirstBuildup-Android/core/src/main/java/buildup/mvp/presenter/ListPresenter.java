package buildup.mvp.presenter;

import java.util.List;

import buildup.core.R;
import buildup.ds.CrudDatasource;
import buildup.ds.Datasource;
import buildup.mvp.view.CrudListView;

public class ListPresenter<T> extends BasePresenter implements ListCrudPresenter<T>, Datasource.Listener<T> {

    private final CrudDatasource<T> crudDatasource;
    private final CrudListView<T> view;

    public ListPresenter(CrudDatasource<T> crudDatasource, CrudListView<T> view) {
        this.crudDatasource = crudDatasource;
        this.view = view;
    }

    @Override
    public void deleteItem(T item) {
        crudDatasource.deleteItem(item, this);
    }

    @Override
    public void deleteItems(List<T> items) {
        crudDatasource.deleteItems(items, this);
    }

    @Override
    public void addForm() {
        view.showAdd();
    }

    @Override
    public void editForm(T item, int position) {
        view.showEdit(item, position);
    }

    @Override
    public void detail(T item, int position) {
        view.showDetail(item, position);
    }

    @Override
    public void onSuccess(T t) {
        view.showMessage(R.string.items_deleted);
        view.refresh();
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic);
    }
}


